<div class="accordion-body">
  <div class="accordion">
    <h1>Frequently Asked Questions</h1>
    <hr />
    <div class="container">
      <div class="label">What is HTML</div>
      <div class="content"></div>
    </div>
  </div>
</div>;
