import Slider from "react-slick";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Header from "./Componentone/Header/Header";
import Headerdown from "./Componentone/headerdown/Headerdown";
import Rarity from "./Componentone/RARITY/Rarity";
import Faq from "./Componentone/FAQ/Faq";
import Footertwo from "./Componentone/Foootertwo/Footertwo";
function AppOne() {
  return (
    <div className="AppOne">
      <Header />
      <Headerdown />
      <Slider />
      <Rarity />
      <Faq />
      <Footertwo />
    </div>
  );
}

export default AppOne;
