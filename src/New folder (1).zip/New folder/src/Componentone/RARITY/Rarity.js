import React from "react";
import "./Rarity.css";
import grop from "../../asset/Group 2559.png";
import grop1 from "../../asset/Ellipse 66.png";
function Rarity() {
  return (
    <div className="backroundColor">
      <div className="container conatiner3">
        <div className="row">
          <div className="col">
            <h2 className="rarityh2">RARITY</h2>
          </div>
        </div>
        {/* <img src={grop1} style={{ zIndex: "1" }} /> */}
        {/* <img src={grop} className="rarityimg" /> */}
      </div>
    </div>
  );
}

export default Rarity;
