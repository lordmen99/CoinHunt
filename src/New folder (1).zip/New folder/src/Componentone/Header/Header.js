import React from "react";
import "./Header.css";
import tato from "../../asset/tato.png";
import { Button } from "react-bootstrap";
import vector9 from "../../asset/Vector 9.png";
function Header() {
  return (
    <div className="container container1">
      <div className="row">
        <h2 className="headerh2">
          HOW MANY{" "}
          <span style={{ color: "#009EFF" }}>
            <b>APES</b>
          </span>{" "}
          <b>DO YOU WANT TO</b>
          <span style={{ color: "#009EFF" }}>
            <b>MINT</b>
          </span>
          ?
        </h2>
      </div>
      <div
        className="row"
        style={{
          display: "flex",
          alignSelf: "center",
          //   border: "2px solid red",
        }}
      >
        <div className="col-md-4" style={{ alignSelf: "center" }}>
          <img src={tato} className="headerimg" />
        </div>
        <div className="col-4">
          <div className="headerboxes">
            <h3 className="headerh3">
              <b>SALE IS OPEN</b>
            </h3>
            <div
              className="row"
              style={{
                display: "flex",
                justifyContent: "center",
                // border: "2px solid red",
              }}
            >
              <div
                className="col-7"
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                }}
              >
                <h4 className="headerh44">
                  <b>Amount</b>
                </h4>
                <div className="divvvv">
                  <button class="astext">-</button>
                  <span className="astex1">1</span>
                  <button class="astext">+</button>
                </div>
              </div>
            </div>
            <img
              src={vector9}
              width="240px"
              style={{ paddingBottom: "49px" }}
            />
            <div
              className="row"
              style={{
                display: "flex",
                justifyContent: "center",
                // border: "2px solid red",
              }}
            >
              <div
                className="col-7"
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                }}
              >
                <h4 className="headerh444">
                  <b>Cost</b>
                </h4>
                <span className="headerh444">
                  <b>0.12 ETH</b>
                </span>
                {/* <div className="divvvv">
                  
                </div> */}
              </div>
            </div>
            <img
              src={vector9}
              width="240px"
              style={{ paddingBottom: "49px" }}
            />
            <div>
              <p className="headerp">
                <b>SYAC Minted: 4398/6999</b>
              </p>
              <p className="headerp">
                <b>Connect your wallet to see</b>
                <br /> <b>the accurate count</b>
              </p>
            </div>
            <div
              className="row"
              style={{
                display: "flex",
                justifyContent: "center",
                // border: "2px solid red",
              }}
            >
              <div className="col-7">
                <div className="d-grid gap-2 my-2">
                  <Button variant="secondary">
                    <b>Block level button</b>
                  </Button>
                </div>
                <div className="d-grid gap-2">
                  <Button variant="secondary">
                    <b>Block level button</b>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-4" style={{ alignSelf: "center" }}>
          <img src={tato} className="headerimg" />
        </div>
      </div>
    </div>
  );
}

export default Header;
