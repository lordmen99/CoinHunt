import React, { useState } from "react";
import "./Faq.css";
const Accordion = ({ title, content }) => {
  const [isActive, setIsActive] = useState(false);

  return (
    <div>
      <hr />
      <div onClick={() => setIsActive(!isActive)}>
        <div class="label">{title}</div>
      </div>
      {isActive && <div>{content}</div>}
    </div>
  );
};

export default Accordion;
